# daily-bistro

## Demo HTML template

1. Extract this archive.
2. Open index.html in your browser.
3. Replace the demo text and SVG resources as needed.
4. Upload the folder to any static hosting service.

## Included files

- index.html
- styles.css
- script.js
- assets/

This package is provided for demonstration purposes.
